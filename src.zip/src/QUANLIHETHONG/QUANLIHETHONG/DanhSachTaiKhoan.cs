﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QUANLIHETHONG
{
    internal class DanhSachTaiKhoan
    {
        private static DanhSachTaiKhoan instance;
        public static DanhSachTaiKhoan Ininstance 
        {
            get
            { 
                if (instance == null)
                    instance = new DanhSachTaiKhoan();
                return instance; 
            }
            set => instance = value;
        }

        List<TaiKhoan> listTaiKhoan;
        public List<TaiKhoan> ListTaiKhoan
        {
            get => listTaiKhoan;
            set => listTaiKhoan = value;
        }

        DanhSachTaiKhoan()
        {
            listTaiKhoan = new List<TaiKhoan>();
            listTaiKhoan.Add(new TaiKhoan("doitac", "doitac",TaiKhoan.LoaiTK.doitac));
            listTaiKhoan.Add(new TaiKhoan("khachhang", "khachhang", TaiKhoan.LoaiTK.khachhang));
            listTaiKhoan.Add(new TaiKhoan("taixe", "taixe", TaiKhoan.LoaiTK.taixe));
            listTaiKhoan.Add(new TaiKhoan("nhanvien", "nhanvien", TaiKhoan.LoaiTK.nhanvien));
            listTaiKhoan.Add(new TaiKhoan("admin", "admin", TaiKhoan.LoaiTK.admin));

        }
    }
}
