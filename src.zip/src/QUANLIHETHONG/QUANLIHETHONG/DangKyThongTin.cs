﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QUANLIHETHONG
{
    public partial class frmDangKyThongTin : Form
    {
        string strCon = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        //Đối tượng kết nối
        SqlConnection sqlCon = null;
        public frmDangKyThongTin()
        {
            InitializeComponent();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {

            try
            {
                if (sqlCon == null)
                {
                    sqlCon = new SqlConnection(strCon); // khong co thi mo ket noi
                }
                //mở kết nối
                if (sqlCon.State == ConnectionState.Closed)
                {
                    sqlCon.Open();

                    SqlCommand cmd = new SqlCommand("insert into DoiTac values (@MaDoiTac,@TenQuan,@Email,@ThanhPho,@Quan,@SLChiNhanh,@SLDonHang,@LoaiAmThuc,@SDT)", sqlCon);
                    cmd.Parameters.AddWithValue("@MaDoiTac", txtMaDoiTac.Text);
                    cmd.Parameters.AddWithValue("@TenQuan", txtTenQuan.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@ThanhPho", txtThanhPho.Text);
                    cmd.Parameters.AddWithValue("@Quan", txtQuan.Text);
                    cmd.Parameters.AddWithValue("@SLChiNhanh", txtSLChiNhanh.Text);
                    cmd.Parameters.AddWithValue("@SLDonHang", txtSLDonHang.Text);
                    cmd.Parameters.AddWithValue("@LoaiAmThuc", txtLoaiAmThuc.Text);
                    cmd.Parameters.AddWithValue("@SDT",txtSDT.Text);
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                    MessageBox.Show("Successfully Saved");
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
