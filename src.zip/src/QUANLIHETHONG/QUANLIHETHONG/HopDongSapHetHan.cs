﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLIHETHONG
{
    public partial class frmHopDongSapHetHan : Form
    {
        string serverName = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        public frmHopDongSapHetHan()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(serverName);
            Con.Open();

            string sql = "Select * from HopDong where DATEDIFF(day,NgayKT,@NgayHienTai) > 30 and  TrangThaiDuyet = 'Y'";
            SqlCommand cmd = new SqlCommand(sql, Con);
            cmd.Parameters.Add("@NgayHienTai", DateTime.Now);

            cmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            Con.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView1.CurrentRow.Index;
            textBox1.Text = dataGridView1.Rows[i].Cells[7].Value.ToString();
        }
    }
}
