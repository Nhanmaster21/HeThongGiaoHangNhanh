﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QUANLIHETHONG
{
    public partial class frmTiepNhanDon : Form
    {
        string strCon = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        //Đối tượng kết nối
        SqlConnection sqlCon = null;
        public frmTiepNhanDon()
        {
            InitializeComponent();
        }

        private void btnCapNhatTT_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon == null)
                {
                    sqlCon = new SqlConnection(strCon); // khong co thi mo ket noi
                }
                //mở kết nối
                if (sqlCon.State == ConnectionState.Closed)
                {
                    sqlCon.Open();
                    SqlCommand cmd = new SqlCommand("update Donhang set TinhTrang = @TinhTrangDon where MaDH = @MaDonHang", sqlCon);
                    SqlCommand cmd_result = new SqlCommand("select MaDH,TinhTrang from Donhang where MaDH = @MaDonHang", sqlCon);
                    cmd.Parameters.AddWithValue("@MaDonHang", tb_MaDonHang.Text);
                    cmd.Parameters.AddWithValue("@TinhTrangDon", tb_CapNhatTrangThai.Text);
                    cmd_result.Parameters.AddWithValue("@MaDonHang", tb_MaDonHang.Text);
                    cmd.ExecuteNonQuery();
                    cmd_result.ExecuteNonQuery();
                    SqlDataAdapter da = new SqlDataAdapter(cmd_result);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView2.DataSource = dt;
                    MessageBox.Show("Successfully Update");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDanhSachDon_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection Con = new SqlConnection(strCon);
                Con.Open();
                SqlCommand cmd = new SqlCommand("SELECT  TOP 20 * FROM dbo.TaiXe,dbo.DonHang WHERE TaiXe.KVHoatDong=(SELECT KVHoatDong FROM dbo.TaiXe WHERE MaTaiXe =@MaTaiXe) AND dbo.TaiXe.MaTaiXe = dbo.DonHang.MaTaiXe", Con);
                cmd.Parameters.AddWithValue("@MaTaiXe", textBox1.Text);
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                int i;
                i = dataGridView1.CurrentRow.Index;
                tb_MaDonHang.Text = dataGridView1.Rows[i].Cells[8].Value.ToString();

                textBox7.Text = dataGridView1.Rows[i].Cells[6].Value.ToString();
                tb_TinhTrangDon.Text = dataGridView1.Rows[i].Cells[13].Value.ToString();
            }
        }
    }
}
