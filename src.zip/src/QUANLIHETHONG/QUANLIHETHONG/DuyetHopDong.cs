﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QUANLIHETHONG
{
    public partial class frmDuyetHopDong : Form
    {
        string serverName = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        public frmDuyetHopDong()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(serverName);
            Con.Open();
            string sql = "Select TrangThaiDuyet from HopDong where MaHopDong = @MaHopDong";
            SqlCommand cmd = new SqlCommand(sql, Con);
            cmd.Parameters.Add("@MaHopDong", textBox1.Text);

            var check = cmd.ExecuteScalar();
            if (Convert.ToChar(check) == 'Y')
            {
                MessageBox.Show("Hop dong da duyet");
            }
            else
            {
                string sql1 = "Update HopDong set TrangThaiDuyet = 'Y' where MaHopDong = @MaHopDong";
                SqlCommand cmd1 = new SqlCommand(sql1, Con);
                cmd1.Parameters.Add("@MaHopDong", textBox1.Text);
                cmd1.ExecuteNonQuery();
                MessageBox.Show("Da duyet hop dong");
            }
            Con.Close();
        }
    }
}
