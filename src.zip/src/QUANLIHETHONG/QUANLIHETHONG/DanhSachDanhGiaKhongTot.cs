﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLIHETHONG
{
    public partial class frmDanhSachDanhGiaKhongTot : Form
    {
        string serverName = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        public frmDanhSachDanhGiaKhongTot()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(serverName);
            Con.Open();

            string sql = "Select DH.DanhGia, CH.TenQuan from DonHang DH inner join CuaHang CH on DH.MaCH = CH.MaCH and DH.DanhGia = N'Tệ' ";
            SqlCommand cmd = new SqlCommand(sql, Con);

            cmd.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            Con.Close();
        }
    }
}
