﻿namespace QUANLIHETHONG
{
    partial class frmChuongTrinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnXemHopDong = new System.Windows.Forms.Button();
            this.btnLuongKH = new System.Windows.Forms.Button();
            this.btnHoaHong = new System.Windows.Forms.Button();
            this.btnDoanhThu = new System.Windows.Forms.Button();
            this.btnHDSapHetHan = new System.Windows.Forms.Button();
            this.btnDuyetHopDong = new System.Windows.Forms.Button();
            this.btnDSHopDongDaLap = new System.Windows.Forms.Button();
            this.btnDanhGiaKhongTot = new System.Windows.Forms.Button();
            this.btnCapNhatThongTinTK = new System.Windows.Forms.Button();
            this.btnDangKyTaiXe = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtLoaiTK = new System.Windows.Forms.TextBox();
            this.btnTheoDoiThuNhap = new System.Windows.Forms.Button();
            this.btnTiepNhanvaXuLyDon = new System.Windows.Forms.Button();
            this.btnDatHang = new System.Windows.Forms.Button();
            this.btnTheoDoiDon = new System.Windows.Forms.Button();
            this.btnDangKyThanhVien = new System.Windows.Forms.Button();
            this.btnDangKyThongTin = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnXemHopDong);
            this.panel1.Controls.Add(this.btnLuongKH);
            this.panel1.Controls.Add(this.btnHoaHong);
            this.panel1.Controls.Add(this.btnDoanhThu);
            this.panel1.Controls.Add(this.btnHDSapHetHan);
            this.panel1.Controls.Add(this.btnDuyetHopDong);
            this.panel1.Controls.Add(this.btnDSHopDongDaLap);
            this.panel1.Controls.Add(this.btnDanhGiaKhongTot);
            this.panel1.Controls.Add(this.btnCapNhatThongTinTK);
            this.panel1.Controls.Add(this.btnDangKyTaiXe);
            this.panel1.Controls.Add(this.btnThoat);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtLoaiTK);
            this.panel1.Controls.Add(this.btnTheoDoiThuNhap);
            this.panel1.Controls.Add(this.btnTiepNhanvaXuLyDon);
            this.panel1.Controls.Add(this.btnDatHang);
            this.panel1.Controls.Add(this.btnTheoDoiDon);
            this.panel1.Controls.Add(this.btnDangKyThanhVien);
            this.panel1.Controls.Add(this.btnDangKyThongTin);
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(864, 367);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnXemHopDong
            // 
            this.btnXemHopDong.Location = new System.Drawing.Point(558, 304);
            this.btnXemHopDong.Margin = new System.Windows.Forms.Padding(2);
            this.btnXemHopDong.Name = "btnXemHopDong";
            this.btnXemHopDong.Size = new System.Drawing.Size(127, 38);
            this.btnXemHopDong.TabIndex = 25;
            this.btnXemHopDong.Text = "Xem hợp đồng";
            this.btnXemHopDong.UseVisualStyleBackColor = true;
            this.btnXemHopDong.Click += new System.EventHandler(this.btnXemHopDong_Click);
            // 
            // btnLuongKH
            // 
            this.btnLuongKH.Location = new System.Drawing.Point(382, 304);
            this.btnLuongKH.Margin = new System.Windows.Forms.Padding(2);
            this.btnLuongKH.Name = "btnLuongKH";
            this.btnLuongKH.Size = new System.Drawing.Size(127, 38);
            this.btnLuongKH.TabIndex = 24;
            this.btnLuongKH.Text = "Thống kê lượng khách hàng";
            this.btnLuongKH.UseVisualStyleBackColor = true;
            this.btnLuongKH.Click += new System.EventHandler(this.btnLuongKH_Click);
            // 
            // btnHoaHong
            // 
            this.btnHoaHong.Location = new System.Drawing.Point(382, 232);
            this.btnHoaHong.Margin = new System.Windows.Forms.Padding(2);
            this.btnHoaHong.Name = "btnHoaHong";
            this.btnHoaHong.Size = new System.Drawing.Size(127, 38);
            this.btnHoaHong.TabIndex = 23;
            this.btnHoaHong.Text = "Thống kê hoa hồng";
            this.btnHoaHong.UseVisualStyleBackColor = true;
            this.btnHoaHong.Click += new System.EventHandler(this.btnHoaHong_Click);
            // 
            // btnDoanhThu
            // 
            this.btnDoanhThu.Location = new System.Drawing.Point(382, 156);
            this.btnDoanhThu.Margin = new System.Windows.Forms.Padding(2);
            this.btnDoanhThu.Name = "btnDoanhThu";
            this.btnDoanhThu.Size = new System.Drawing.Size(127, 38);
            this.btnDoanhThu.TabIndex = 22;
            this.btnDoanhThu.Text = "Thống kê doanh thu";
            this.btnDoanhThu.UseVisualStyleBackColor = true;
            this.btnDoanhThu.Click += new System.EventHandler(this.btnDoanhThu_Click);
            // 
            // btnHDSapHetHan
            // 
            this.btnHDSapHetHan.Location = new System.Drawing.Point(382, 82);
            this.btnHDSapHetHan.Margin = new System.Windows.Forms.Padding(2);
            this.btnHDSapHetHan.Name = "btnHDSapHetHan";
            this.btnHDSapHetHan.Size = new System.Drawing.Size(127, 38);
            this.btnHDSapHetHan.TabIndex = 21;
            this.btnHDSapHetHan.Text = "Hợp đồng sắp hết hạn";
            this.btnHDSapHetHan.UseVisualStyleBackColor = true;
            this.btnHDSapHetHan.Click += new System.EventHandler(this.btnHDSapHetHan_Click);
            // 
            // btnDuyetHopDong
            // 
            this.btnDuyetHopDong.Location = new System.Drawing.Point(382, 10);
            this.btnDuyetHopDong.Margin = new System.Windows.Forms.Padding(2);
            this.btnDuyetHopDong.Name = "btnDuyetHopDong";
            this.btnDuyetHopDong.Size = new System.Drawing.Size(127, 38);
            this.btnDuyetHopDong.TabIndex = 20;
            this.btnDuyetHopDong.Text = "Duyệt hợp đồng";
            this.btnDuyetHopDong.UseVisualStyleBackColor = true;
            this.btnDuyetHopDong.Click += new System.EventHandler(this.btnDuyetHopDong_Click);
            // 
            // btnDSHopDongDaLap
            // 
            this.btnDSHopDongDaLap.Location = new System.Drawing.Point(201, 304);
            this.btnDSHopDongDaLap.Margin = new System.Windows.Forms.Padding(2);
            this.btnDSHopDongDaLap.Name = "btnDSHopDongDaLap";
            this.btnDSHopDongDaLap.Size = new System.Drawing.Size(127, 38);
            this.btnDSHopDongDaLap.TabIndex = 19;
            this.btnDSHopDongDaLap.Text = "Danh sách hợp đồng đã lập";
            this.btnDSHopDongDaLap.UseVisualStyleBackColor = true;
            this.btnDSHopDongDaLap.Click += new System.EventHandler(this.btnDSHopDongDaLap_Click);
            // 
            // btnDanhGiaKhongTot
            // 
            this.btnDanhGiaKhongTot.Location = new System.Drawing.Point(201, 232);
            this.btnDanhGiaKhongTot.Margin = new System.Windows.Forms.Padding(2);
            this.btnDanhGiaKhongTot.Name = "btnDanhGiaKhongTot";
            this.btnDanhGiaKhongTot.Size = new System.Drawing.Size(127, 38);
            this.btnDanhGiaKhongTot.TabIndex = 18;
            this.btnDanhGiaKhongTot.Text = "Danh sách đánh giá không tốt";
            this.btnDanhGiaKhongTot.UseVisualStyleBackColor = true;
            this.btnDanhGiaKhongTot.Click += new System.EventHandler(this.btnDanhGiaKhongTot_Click);
            // 
            // btnCapNhatThongTinTK
            // 
            this.btnCapNhatThongTinTK.Location = new System.Drawing.Point(201, 156);
            this.btnCapNhatThongTinTK.Margin = new System.Windows.Forms.Padding(2);
            this.btnCapNhatThongTinTK.Name = "btnCapNhatThongTinTK";
            this.btnCapNhatThongTinTK.Size = new System.Drawing.Size(127, 38);
            this.btnCapNhatThongTinTK.TabIndex = 17;
            this.btnCapNhatThongTinTK.Text = "Cập nhật thông tin tài khoản";
            this.btnCapNhatThongTinTK.UseVisualStyleBackColor = true;
            this.btnCapNhatThongTinTK.Click += new System.EventHandler(this.btnCapNhatThongTinTK_Click);
            // 
            // btnDangKyTaiXe
            // 
            this.btnDangKyTaiXe.Location = new System.Drawing.Point(26, 156);
            this.btnDangKyTaiXe.Margin = new System.Windows.Forms.Padding(2);
            this.btnDangKyTaiXe.Name = "btnDangKyTaiXe";
            this.btnDangKyTaiXe.Size = new System.Drawing.Size(127, 38);
            this.btnDangKyTaiXe.TabIndex = 16;
            this.btnDangKyTaiXe.Text = "Đăng ký tài xế";
            this.btnDangKyTaiXe.UseVisualStyleBackColor = true;
            this.btnDangKyTaiXe.Click += new System.EventHandler(this.btnDangKyTaiXe_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(735, 67);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(2);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(85, 38);
            this.btnThoat.TabIndex = 15;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(712, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 22);
            this.label1.TabIndex = 14;
            this.label1.Text = "Loại tài khoản";
            // 
            // txtLoaiTK
            // 
            this.txtLoaiTK.Location = new System.Drawing.Point(713, 43);
            this.txtLoaiTK.Margin = new System.Windows.Forms.Padding(2);
            this.txtLoaiTK.MaximumSize = new System.Drawing.Size(151, 200);
            this.txtLoaiTK.MaxLength = 40000;
            this.txtLoaiTK.Name = "txtLoaiTK";
            this.txtLoaiTK.ReadOnly = true;
            this.txtLoaiTK.Size = new System.Drawing.Size(139, 20);
            this.txtLoaiTK.TabIndex = 13;
            // 
            // btnTheoDoiThuNhap
            // 
            this.btnTheoDoiThuNhap.Location = new System.Drawing.Point(201, 82);
            this.btnTheoDoiThuNhap.Margin = new System.Windows.Forms.Padding(2);
            this.btnTheoDoiThuNhap.Name = "btnTheoDoiThuNhap";
            this.btnTheoDoiThuNhap.Size = new System.Drawing.Size(127, 38);
            this.btnTheoDoiThuNhap.TabIndex = 9;
            this.btnTheoDoiThuNhap.Text = "Theo dõi thu nhập";
            this.btnTheoDoiThuNhap.UseVisualStyleBackColor = true;
            this.btnTheoDoiThuNhap.Click += new System.EventHandler(this.btnTheoDoiThuNhap_Click);
            // 
            // btnTiepNhanvaXuLyDon
            // 
            this.btnTiepNhanvaXuLyDon.Location = new System.Drawing.Point(201, 10);
            this.btnTiepNhanvaXuLyDon.Margin = new System.Windows.Forms.Padding(2);
            this.btnTiepNhanvaXuLyDon.Name = "btnTiepNhanvaXuLyDon";
            this.btnTiepNhanvaXuLyDon.Size = new System.Drawing.Size(127, 38);
            this.btnTiepNhanvaXuLyDon.TabIndex = 8;
            this.btnTiepNhanvaXuLyDon.Text = "Tiếp nhận và xử lý đơn hàng";
            this.btnTiepNhanvaXuLyDon.UseVisualStyleBackColor = true;
            this.btnTiepNhanvaXuLyDon.Click += new System.EventHandler(this.btnTiepNhanvaXuLyDon_Click);
            // 
            // btnDatHang
            // 
            this.btnDatHang.Location = new System.Drawing.Point(26, 304);
            this.btnDatHang.Margin = new System.Windows.Forms.Padding(2);
            this.btnDatHang.Name = "btnDatHang";
            this.btnDatHang.Size = new System.Drawing.Size(127, 38);
            this.btnDatHang.TabIndex = 7;
            this.btnDatHang.Text = "Đặt hàng";
            this.btnDatHang.UseVisualStyleBackColor = true;
            this.btnDatHang.Click += new System.EventHandler(this.btnDatHang_Click);
            // 
            // btnTheoDoiDon
            // 
            this.btnTheoDoiDon.Location = new System.Drawing.Point(26, 232);
            this.btnTheoDoiDon.Margin = new System.Windows.Forms.Padding(2);
            this.btnTheoDoiDon.Name = "btnTheoDoiDon";
            this.btnTheoDoiDon.Size = new System.Drawing.Size(127, 38);
            this.btnTheoDoiDon.TabIndex = 6;
            this.btnTheoDoiDon.Text = "Theo dõi đơn ";
            this.btnTheoDoiDon.UseVisualStyleBackColor = true;
            this.btnTheoDoiDon.Click += new System.EventHandler(this.btnTheoDoiDon_Click);
            // 
            // btnDangKyThanhVien
            // 
            this.btnDangKyThanhVien.Location = new System.Drawing.Point(26, 82);
            this.btnDangKyThanhVien.Margin = new System.Windows.Forms.Padding(2);
            this.btnDangKyThanhVien.Name = "btnDangKyThanhVien";
            this.btnDangKyThanhVien.Size = new System.Drawing.Size(127, 38);
            this.btnDangKyThanhVien.TabIndex = 5;
            this.btnDangKyThanhVien.Text = "Đăng ký khách hàng";
            this.btnDangKyThanhVien.UseVisualStyleBackColor = true;
            this.btnDangKyThanhVien.Click += new System.EventHandler(this.btnDangKyThanhVien_Click);
            // 
            // btnDangKyThongTin
            // 
            this.btnDangKyThongTin.Location = new System.Drawing.Point(26, 10);
            this.btnDangKyThongTin.Margin = new System.Windows.Forms.Padding(2);
            this.btnDangKyThongTin.Name = "btnDangKyThongTin";
            this.btnDangKyThongTin.Size = new System.Drawing.Size(127, 38);
            this.btnDangKyThongTin.TabIndex = 0;
            this.btnDangKyThongTin.Text = "Đăng ký thông tin ";
            this.btnDangKyThongTin.UseVisualStyleBackColor = true;
            this.btnDangKyThongTin.Click += new System.EventHandler(this.btnDangKyThongTin_Click);
            // 
            // frmChuongTrinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 364);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmChuongTrinh";
            this.Text = "Chương trình";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmChuongTrinh_FormClosing);
            this.Load += new System.EventHandler(this.frmChuongTrinh_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLoaiTK;
        private System.Windows.Forms.Button btnTheoDoiThuNhap;
        private System.Windows.Forms.Button btnTiepNhanvaXuLyDon;
        private System.Windows.Forms.Button btnDatHang;
        private System.Windows.Forms.Button btnTheoDoiDon;
        private System.Windows.Forms.Button btnDangKyThanhVien;
        private System.Windows.Forms.Button btnDangKyThongTin;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnDangKyTaiXe;
        private System.Windows.Forms.Button btnXemHopDong;
        private System.Windows.Forms.Button btnLuongKH;
        private System.Windows.Forms.Button btnHoaHong;
        private System.Windows.Forms.Button btnDoanhThu;
        private System.Windows.Forms.Button btnHDSapHetHan;
        private System.Windows.Forms.Button btnDuyetHopDong;
        private System.Windows.Forms.Button btnDSHopDongDaLap;
        private System.Windows.Forms.Button btnDanhGiaKhongTot;
        private System.Windows.Forms.Button btnCapNhatThongTinTK;
    }
}