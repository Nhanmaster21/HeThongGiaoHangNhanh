﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace QUANLIHETHONG
{
    public partial class frmTheoDoiThuNhap : Form
    {
        string strCon = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        //Đối tượng kết nối
        SqlConnection sqlCon = null;
        public frmTheoDoiThuNhap()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection Con = new SqlConnection(strCon);
                Con.Open();
                SqlCommand cmd = new SqlCommand("select SUM(TongThanhToan* 0.15) AS TongTienTrongNgay, count(MaDH) as SoLuong from DonHang where DonHang.MaTaiXe = @MaTaiXe_1 and NgayGiao = (SELECT CONVERT(datetime,@NgayGiao))", Con);
                cmd.Parameters.AddWithValue("@MaTaiXe_1", textBox1.Text);
                cmd.Parameters.AddWithValue("@NgayGiao ", textBox2.Text);

                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView2.DataSource = dt;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(strCon);
            Con.Open();
            string sql = "select (TongThanhToan * 0.15) as ThuNhap from DonHang where DonHang.MaTaiXe = @MaTaiXe_1 and MaDH = @MaDonHang";
            string ma = "";
            SqlCommand cmd = new SqlCommand(sql, Con);
            SqlDataReader reader;
            cmd.Parameters.AddWithValue("@MaTaiXe_1", textBox1.Text);
            cmd.Parameters.AddWithValue("@MaDonHang", textBox3.Text);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView2.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridView1.CurrentRow.Index;
            textBox3.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection Con = new SqlConnection(strCon);
                Con.Open();
                SqlCommand cmd = new SqlCommand("select * from DonHang where DonHang.MaTaiXe= @MaTaiXe_1", Con);
                cmd.Parameters.AddWithValue("@MaTaiXe_1", textBox1.Text);
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection Con = new SqlConnection(strCon);
                Con.Open();
                SqlCommand cmd = new SqlCommand("select SUM(TongThanhToan* 0.15) AS TongTienTrongNgay, count(MaDH) as SoLuong from DonHang where DonHang.MaTaiXe = @MaTaiXe_1 and NgayGiao = (SELECT CONVERT(datetime,@NgayGiao))", Con);
                cmd.Parameters.AddWithValue("@MaTaiXe_1", textBox1.Text);
                cmd.Parameters.AddWithValue("@NgayGiao ", textBox2.Text);

                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView2.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection Con = new SqlConnection(strCon);
                Con.Open();
                SqlCommand cmd = new SqlCommand("select SUM(TongThanhToan* 0.15) AS TongTienThang, count(MaDH) as SoLuongCuaThang FROM DonHang WHERE DonHang.MaTaiXe = @MaTaiXe_1 AND MONTH(NgayGiao) = (SELECT(MONTH(@ThangGiao)))", Con);
                cmd.Parameters.AddWithValue("@MaTaiXe_1", textBox1.Text);
                cmd.Parameters.AddWithValue("@ThangGiao ", textBox2.Text);

                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView2.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
