﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLIHETHONG
{
    public partial class frmCapNhatThongTinTK : Form
    {
        string serverName = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        public frmCapNhatThongTinTK()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(serverName);
            Con.Open();
            string sql = "Select TaiKhoan,MatKhau from TaiKhoan";
            SqlCommand cmd = new SqlCommand(sql, Con);
            SqlDataReader reader = cmd.ExecuteReader();
            bool b = false;
            reader.Read();
            if (reader["TaiKhoan"].ToString() == textBox1.Text && reader["MatKhau"].ToString() == textBox2.Text)
            {
                b = true;
            }
            reader.Close();
            if (b = true)
            {
                if (textBox3.Text != textBox4.Text)
                {
                    MessageBox.Show("Mat khau nhap lai khong dung");
                }
                else
                {
                    string sql1 = "Update TaiKhoan set MatKhau = @MatKhau where TaiKhoan = @TaiKhoan";
                    SqlCommand cmd1 = new SqlCommand(sql1, Con);

                    cmd1.Parameters.Add("@TaiKhoan", textBox1.Text);
                    cmd1.Parameters.Add("@MatKhau", textBox3.Text);
                    cmd1.ExecuteNonQuery();
                    MessageBox.Show("Da thay doi mat khau");
                }
            }
            else
            {
                textBox4.Text = b.ToString();
                MessageBox.Show("tai khoan hoac mat khau khong dung");
            }
            Con.Close();
        }
    }
}
