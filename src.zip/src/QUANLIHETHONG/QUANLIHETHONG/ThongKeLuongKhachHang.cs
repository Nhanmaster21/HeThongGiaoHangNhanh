﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLIHETHONG
{
    public partial class frmThongKeLuongKhachHang : Form
    {
        string serverName = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        public frmThongKeLuongKhachHang()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(serverName);
            Con.Open();

            string sql = "Select count(DH.MaDH) as Tong from DonHang DH inner join ChiTietDonHang CTDH on Day(DH.NgayGiao) = @Ngay and Month(DH.NgayGiao) = @Thang and Year(DH.NgayGiao) = @Nam and DH.MaDH = CTDH.MaDH and CTDH.MaDoiTac = @MaDoiTac ";
            SqlCommand cmd = new SqlCommand(sql, Con);
            cmd.Parameters.Add("@Ngay", textBox1.Text);
            cmd.Parameters.Add("@Thang", textBox2.Text);
            cmd.Parameters.Add("@Nam", textBox3.Text);
            cmd.Parameters.Add("@MaDoiTac", textBox5.Text);
            var Sum = cmd.ExecuteScalar();
            textBox4.Text = Sum.ToString();
            Con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(serverName);
            Con.Open();

            string sql = "Select count(DH.MaDH) as Tong from DonHang DH inner join ChiTietDonHang CTDH on Month(DH.NgayGiao) = @Thang and Year(DH.NgayGiao) = @Nam and DH.MaDH = CTDH.MaDH and CTDH.MaDoiTac = @MaDoiTac ";
            SqlCommand cmd = new SqlCommand(sql, Con);
            cmd.Parameters.Add("@Thang", textBox2.Text);
            cmd.Parameters.Add("@Nam", textBox3.Text);
            cmd.Parameters.Add("@MaDoiTac", textBox5.Text);
            var Sum = cmd.ExecuteScalar();
            textBox4.Text = Sum.ToString();
            Con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(serverName);
            Con.Open();

            string sql = "Select count(DH.MaDH) as Tong from DonHang DH inner join ChiTietDonHang CTDH on Year(DH.NgayGiao) = @Nam and DH.MaDH = CTDH.MaDH and CTDH.MaDoiTac = @MaDoiTac ";
            SqlCommand cmd = new SqlCommand(sql, Con);
            cmd.Parameters.Add("@Nam", textBox3.Text);
            cmd.Parameters.Add("@MaDoiTac", textBox5.Text);
            var Sum = cmd.ExecuteScalar();
            textBox4.Text = Sum.ToString();
            Con.Close();
        }
    }
}
