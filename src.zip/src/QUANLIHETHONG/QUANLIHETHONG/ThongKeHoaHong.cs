﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLIHETHONG
{
    public partial class frmThongKeHoaHong : Form
    {
        string serverName = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        public frmThongKeHoaHong()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(serverName);
            Con.Open();
            string sql = "select sum((DH.TongThanhToan * DH.HoaHong) / 100  ) from DonHang DH inner join CuaHang CH on CH.MaCH = DH.MaCH and CH.MaDoiTac = @MaDT";
            SqlCommand cmd = new SqlCommand(sql, Con);
            cmd.Parameters.Add("@MaDT", textBox1.Text);
            var Sum = cmd.ExecuteScalar();
            textBox2.Text = Sum.ToString();
            Con.Close();
        }
    }
}
