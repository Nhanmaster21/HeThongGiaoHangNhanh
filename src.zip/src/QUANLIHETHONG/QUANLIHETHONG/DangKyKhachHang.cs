﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QUANLIHETHONG
{
    public partial class frmDangKyKhachHang : Form
    {
        string strCon = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        //Đối tượng kết nối
        SqlConnection sqlCon = null;
        public frmDangKyKhachHang()
        {
            InitializeComponent();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon == null)
                {
                    sqlCon = new SqlConnection(strCon); // khong co thi mo ket noi
                }
                //mở kết nối
                if (sqlCon.State == ConnectionState.Closed)
                {
                    sqlCon.Open();

                    SqlCommand cmd = new SqlCommand("insert into KhachHang values (@MaKH,@DiaChiKH,@HoTen,@EmailKH,@SDTKH,@SoDu)", sqlCon);
                    cmd.Parameters.AddWithValue("@MaKH", txtMaKH.Text);
                    cmd.Parameters.AddWithValue("@DiaChiKH", txtDiaChi.Text);
                    cmd.Parameters.AddWithValue("@HoTen", txtHoTen.Text);
                    cmd.Parameters.AddWithValue("@EmailKH", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@SDTKH", txtSdt.Text);
                    cmd.Parameters.AddWithValue("@SoDu", txtSoDu.Text);
                    cmd.ExecuteNonQuery();
                    sqlCon.Close();
                    MessageBox.Show("Successfully Saved");
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
