﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QUANLIHETHONG
{
    public partial class frmTheoDoiDonHang : Form
    {
        string strCon = @"Data Source=DESKTOP-CAL94V2\SQLEXPRESS;Initial Catalog=QUANLIHETHONG;Integrated Security=True";
        //Đối tượng kết nối
        SqlConnection sqlCon = null;
        public frmTheoDoiDonHang()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (textBox1.Text == "")
                    MessageBox.Show("Vui lòng nhập mã khách hàng của bạn");
                else
                {
                    SqlConnection Con = new SqlConnection(strCon);
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("SELECT dh.MaKH,dh.NgayGiao,dh.DanhGia, dh.TinhTrang FROM  dbo.DonHang dh WHERE  dh.MaKH=@MaKH", Con);
                    cmd.Parameters.AddWithValue("@MaKH", textBox1.Text);
                    //KH559956

                    cmd.ExecuteNonQuery();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                    Con.Close();
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
                MessageBox.Show("Vui lòng nhập đánh giá vào ô");
            else
            {
                if (textBox1.Text == "")
                    MessageBox.Show("Vui lòng nhập mã khách hàng của bạn");
                else
                {
                    SqlConnection Con = new SqlConnection(strCon);
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE dbo.DonHang SET DanhGia= @DanhGia WHERE MaKH = @MaKH ", Con);
                    cmd.Parameters.AddWithValue("@MaKH", textBox1.Text);
                    cmd.Parameters.AddWithValue("@DanhGia", textBox2.Text);
                    //KH559956
                    //KH033502
                    //KH593918
                    //KH134381

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Đã cập nhật đánh giá của bạn");
                    Con.Close();
                }
            }
        }
    }
}
