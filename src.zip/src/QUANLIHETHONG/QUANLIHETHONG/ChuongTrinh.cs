﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QUANLIHETHONG
{
    public partial class frmChuongTrinh : Form
    {
        public frmChuongTrinh()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
            frmDangNhap f = new frmDangNhap();
            f.Show();
        }

        private void frmChuongTrinh_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(MessageBox.Show("Bạn chắc chắn muốn quay lại đăng nhập" , "Cảnh báo " , MessageBoxButtons.YesNo) != DialogResult.Yes) 
            {
                e.Cancel = true;
            }
        }

        void PhanQuyen()
        {
            switch(Const.TaiKhoan.LoaiTaiKhoan)
            {
                case TaiKhoan.LoaiTK.doitac:
                    btnCapNhatThongTinTK.Enabled = btnDangKyThanhVien.Enabled = btnDangKyTaiXe.Enabled = btnDanhGiaKhongTot.Enabled = btnDSHopDongDaLap.Enabled = btnDuyetHopDong.Enabled = btnHDSapHetHan.Enabled = btnDatHang.Enabled = btnTheoDoiThuNhap.Enabled = btnDoanhThu.Enabled = btnHoaHong.Enabled = btnLuongKH.Enabled = btnTiepNhanvaXuLyDon.Enabled = btnXemHopDong.Enabled = btnTheoDoiDon.Enabled = false;
                    break;
                case TaiKhoan.LoaiTK.admin:
                    btnTheoDoiDon.Enabled = btnDangKyThanhVien.Enabled = btnDatHang.Enabled = btnTiepNhanvaXuLyDon.Enabled = btnTheoDoiThuNhap.Enabled = btnDangKyThanhVien.Enabled = btnDangKyThongTin.Enabled = btnDangKyTaiXe.Enabled = btnDuyetHopDong.Enabled = btnHDSapHetHan.Enabled = btnDanhGiaKhongTot.Enabled = btnDSHopDongDaLap.Enabled = btnHoaHong.Enabled = btnDoanhThu.Enabled = btnLuongKH.Enabled = btnXemHopDong.Enabled = false;
                    break;
                case TaiKhoan.LoaiTK.khachhang:
                    btnTiepNhanvaXuLyDon.Enabled = btnTheoDoiThuNhap.Enabled  = btnDangKyThongTin.Enabled =  btnDangKyTaiXe.Enabled = btnDuyetHopDong.Enabled = btnHDSapHetHan.Enabled = btnDanhGiaKhongTot.Enabled = btnDSHopDongDaLap.Enabled = btnHoaHong.Enabled = btnDoanhThu.Enabled = btnLuongKH.Enabled = btnXemHopDong.Enabled = btnCapNhatThongTinTK.Enabled = false;
                    break;
                case TaiKhoan.LoaiTK.nhanvien:
                    btnTheoDoiDon.Enabled = btnDangKyThanhVien.Enabled = btnDatHang.Enabled = btnTiepNhanvaXuLyDon.Enabled = btnTheoDoiThuNhap.Enabled = btnDangKyThanhVien.Enabled = btnDangKyThongTin.Enabled = btnDangKyTaiXe.Enabled = btnCapNhatThongTinTK.Enabled = false;
                    break;
                case TaiKhoan.LoaiTK.taixe:
                    btnTheoDoiDon.Enabled = btnDatHang.Enabled = btnDangKyThongTin.Enabled = btnDangKyThanhVien.Enabled = btnDuyetHopDong.Enabled = btnHDSapHetHan.Enabled = btnDanhGiaKhongTot.Enabled = btnDSHopDongDaLap.Enabled = btnHoaHong.Enabled = btnDoanhThu.Enabled = btnLuongKH.Enabled = btnXemHopDong.Enabled = btnCapNhatThongTinTK.Enabled = false;
                    break;
            }
            txtLoaiTK.Text = Const.TaiKhoan.TenHienThi;
        }

        private void frmChuongTrinh_Load(object sender, EventArgs e)
        {
            PhanQuyen();
        }

        private void btnDangKyThongTin_Click(object sender, EventArgs e)
        {
            frmDangKyThongTin f = new frmDangKyThongTin();
            f.ShowDialog();
        }

        private void btnDangKyThanhVien_Click(object sender, EventArgs e)
        {
            frmDangKyKhachHang f = new frmDangKyKhachHang();
            f.ShowDialog();
        }

        private void btnDangKyTaiXe_Click(object sender, EventArgs e)
        {
            frmDangKyTaiXe f = new frmDangKyTaiXe();
            f.ShowDialog();
        }

        private void btnTheoDoiThuNhap_Click(object sender, EventArgs e)
        {
            frmTheoDoiThuNhap f = new frmTheoDoiThuNhap();
            f.ShowDialog();
        }

        private void btnTiepNhanvaXuLyDon_Click(object sender, EventArgs e)
        {
            frmTiepNhanDon f = new frmTiepNhanDon();
            f.ShowDialog();
        }

        private void btnDatHang_Click(object sender, EventArgs e)
        {
            frmThanhToan f = new frmThanhToan();
            f.ShowDialog();
        }

        private void btnTheoDoiDon_Click(object sender, EventArgs e)
        {
            frmTheoDoiDonHang f = new frmTheoDoiDonHang();
            f.ShowDialog();
        }

        private void btnQuanLyDoiTac_Click(object sender, EventArgs e)
        {

        }

        private void btnXacNhanHopDong_Click(object sender, EventArgs e)
        {

        }

        private void btnQuanLyTaiKhoan_Click(object sender, EventArgs e)
        {

        }

        private void btnCapNhatThongTinTK_Click(object sender, EventArgs e)
        {
            frmCapNhatThongTinTK f = new frmCapNhatThongTinTK();
            f.ShowDialog();
        }

        private void btnDanhGiaKhongTot_Click(object sender, EventArgs e)
        {
            frmDanhSachDanhGiaKhongTot f = new frmDanhSachDanhGiaKhongTot();
            f.ShowDialog();
        }

        private void btnDSHopDongDaLap_Click(object sender, EventArgs e)
        {
            frmDanhSachHopDongDaLap f = new frmDanhSachHopDongDaLap();
            f.ShowDialog();
        }

        private void btnDuyetHopDong_Click(object sender, EventArgs e)
        {
            frmDuyetHopDong f = new frmDuyetHopDong();
            f.ShowDialog();
        }

        private void btnHDSapHetHan_Click(object sender, EventArgs e)
        {
            frmHopDongSapHetHan f = new frmHopDongSapHetHan();
            f.ShowDialog();
        }

        private void btnDoanhThu_Click(object sender, EventArgs e)
        {
            frmThongKeDoanhThu f = new frmThongKeDoanhThu();
            f.ShowDialog();
        }

        private void btnHoaHong_Click(object sender, EventArgs e)
        {
            frmThongKeHoaHong f = new frmThongKeHoaHong();
            f.ShowDialog();
        }

        private void btnLuongKH_Click(object sender, EventArgs e)
        {
            frmThongKeLuongKhachHang f = new frmThongKeLuongKhachHang();
            f.ShowDialog();
        }

        private void btnXemHopDong_Click(object sender, EventArgs e)
        {
            frmXemHopDong f = new frmXemHopDong();
            f.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
